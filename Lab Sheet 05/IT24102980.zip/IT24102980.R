setwd("C:\\Users\\it24102980\\Desktop\\IT24102980")
Delivery_Times <- read.table("C:\\Users\\it24102980\\Desktop\\IT24102980\\Exercise_Lab_05.txt.txt", header = TRUE, sep = "\t")
list.files("C:\\Users\\it24102980\\Desktop\\IT24102980")
fix(Delivery_Times)
attach(Delivery_Times)
print(Delivery_Times)
par(mar = c(5, 4, 4, 2) + 0.1)
dev.off() 
hist(Delivery_Times$Delivery,
     breaks = seq(20,70, by = 5),
     right = FALSE,
     main="Histogram of delivery times",
     xlab = "Delevery Times",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")

hist_data<-hist(Delivery_Times$Delivery,
                breaks = seq(20,70,by=5),
                right  =FALSE,
                plot=FALSE)

cumulative_freq<-cumsum(hist_data$counts)
plot(hist_data$mids, cumulative_freq,
     type = "l",  
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Times",
     ylab = "Cumulative Frequency",
     col = "blue",  
     lwd = 2)       

