setwd("C:\\Users\\Administrator\\OneDrive\\Desktop\\IT24102980")
laptop_bag_weights <- scan("LaptopWeights.txt",skip = 1)

pop_mean <- mean(laptop_bag_weights)
pop_sd <- sd(laptop_bag_weights) * sqrt((length(laptop_bag_weights)-1)/length(laptop_bag_weights))

cat("Population Mean =", pop_mean, "\n")
cat("Population Standard Deviation =", pop_sd, "\n\n")

set.seed(123)

sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  samp <- sample(laptop_bag_weights, size=6, replace=TRUE)
  sample_means[i] <- mean(samp)
  sample_sds[i] <- sd(samp)
  cat("Sample", i, ": Mean =", sample_means[i], " SD =", sample_sds[i], "\n")
}

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of 25 Sample Means =", mean_of_sample_means, "\n")
cat("SD of 25 Sample Means =", sd_of_sample_means, "\n")

cat("\nObservations:\n")
cat("1. The mean of the sample means is approximately equal to the population mean.\n")
cat("2. The SD of the sample means is smaller than the population SD.\n")
cat("   -> This matches the Central Limit Theorem.\n")

